def test():
    n, m, start, size = [int(x) for x in input().split()]
    transitions = {}
    for _ in range(m):
        a, b = [int(x) for x in input().split()]
        transitions[a] = b
    current = start
    freq = [0 for _ in range(n)]
    for _ in range(size):
        freq[current-1] += 1
        current = transitions[current]
    print(" ".join([str(x) for x in freq]))

t = int(input())
for _ in range(t):
    test()