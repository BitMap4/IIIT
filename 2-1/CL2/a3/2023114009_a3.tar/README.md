# Assignment 3

## Requirements

- `regex` module from PyPi

```sh
pip install regex
```

## Running the code

Download the language datasets folder and run all cells in [`main.ipynb`](main.ipynb).
