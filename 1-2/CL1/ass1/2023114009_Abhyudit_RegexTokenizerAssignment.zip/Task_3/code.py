import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from tokeniser import *

data = tokeniser('pg98.txt')
freq = process3(data)
with open('Task_3/output.txt', 'w') as f:
    for k in freq:
        f.write(f'{k} {freq[k]}\n')
    print('Task 3 completed')