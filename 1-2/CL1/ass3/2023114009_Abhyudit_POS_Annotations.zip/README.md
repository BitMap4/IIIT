## Sources

- Hindi: https://www.jagranjosh.com/general-knowledge/interesting-facts-about-pi-value-1710404560-2
- English: https://www.forbes.com/sites/ewanspence/2024/03/10/pple-iphone-16-camera-specs-leak-design-new-iphone/?sh=1bf7b83a5ce0

## Tagset

- Hindi: BIS Tagset for Hindi
- English: Same as Hindi, but with an extra determiner tag
