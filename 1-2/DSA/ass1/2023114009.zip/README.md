# Assignment 1

- All input strings have maximum length of 100.
- `create_platform` should be the first function called.
- I/O format given in the assignment pdf is followed, except for `view_all_comments`, instead of which, `view_comments` is used.
- A list of available commands is visible whenever the program is waiting for the user to call a function.
- The makefile gives a file called `main` as output. This is the executable file.
