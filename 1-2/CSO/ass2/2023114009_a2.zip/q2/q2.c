#include <stdio.h>
typedef long long E;

extern E choose(E n, E r);
// {
//     if (r == 0) {
//         return 1;
//     }
//     E d = n-r;
//     if (d < r) {
//         r = d;
//     }
//     E ans = n;
//     ans *= choose(n-1, r-1);
//     ans /= r;
//     return ans;
// }

int main() {
    E n, r;
    scanf("%lld%lld", &n, &r);
    printf("%lld\n", choose(n, r));
    return 0;
}