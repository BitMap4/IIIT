#include <stdio.h>
typedef long long E;

extern void binary_s(E * arr, int x, E* iter);

int main() {
    E arr[32], iter=0, x;
    for (E i=0; i<32; i++) {
        scanf("%lld", &arr[i]);
    }
    scanf("%lld", &x);
    binary_s(arr, x, &iter);
    printf("%lld %lld\n", result[0], result[1]);
    return 0;
}